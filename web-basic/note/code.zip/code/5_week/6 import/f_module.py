class F:
    def __str__(self):
        return "F Module!"
