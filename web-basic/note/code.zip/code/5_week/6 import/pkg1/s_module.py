class S1:
    def __str__(self):
        return "S1 Module!"
