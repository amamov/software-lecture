class S2:
    def __str__(self):
        return "S2 Module!!"
